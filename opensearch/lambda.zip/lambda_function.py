import boto3
import re
import requests
from requests_aws4auth import AWS4Auth

region = 'us-east-1' # e.g. us-west-1
service = 'es'
credentials = boto3.Session().get_credentials()
awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, service, session_token=credentials.token)

# the OpenSearch Service domain, e.g. https://search-mydomain.us-west-1.es.amazonaws.com
host = 'https://search-knn-server-jgbseyuiok6tfqds2ufnqqn6s4.us-east-1.es.amazonaws.com' 
index = 'autel-vector-index'
type = '_doc'
url = host + '/' + index + '/' + type

headers = { "Content-Type": "application/json" }

s3 = boto3.client('s3')

# Regular expressions used to parse some simple log lines
ip_pattern = re.compile('(\d+\.\d+\.\d+\.\d+)')
time_pattern = re.compile('\[(\d+\/\w\w\w\/\d\d\d\d:\d\d:\d\d:\d\d\s-\d\d\d\d)\]')
message_pattern = re.compile('\"(.+)\"')

# Lambda execution starts here
def handler(event, context):
    for record in event['Records']:

        # Get the bucket name and key for the new file
        bucket = record['s3']['bucket']['name']
        key = record['s3']['object']['key']

        # Get, read, and split the file into lines
        obj = s3.get_object(Bucket=bucket, Key=key)
        body = obj['Body'].read()
        lines = body.splitlines()

        print("start import:" + key)
        counts = 0
        # Match the regular expressions to each line and index the JSON
        for line in lines:

            line = line.decode("utf-8")
            # print(line)
            cols = line.split(",")
            func_id = cols[0]
            sys_cn = cols[1]
            sys_en = cols[2]
            func_name_cn = cols[3]
            func_name_cn_vector = cols[4]
            func_name_en = cols[5]
            func_name_en_vector = cols[6]
            car_relative_path = cols[7]
            func_path_cn = cols[8]
            func_path_en = cols[9]
            func_des_cn = cols[10]
            func_des_cn_vector = cols[11]
            func_des_en = cols[12]
            func_des_en_vector = cols[13]
            func_type = cols[14]

            document = { "func_id": func_id, "sys_cn": sys_cn, "sys_en": sys_en,
                            "func_name_cn": func_name_cn,
                            "func_name_cn_vector": func_name_cn_vector,
                            "func_name_en": func_name_en,
                            "func_name_en_vector": func_name_en_vector,
                            "car_relative_path": car_relative_path,
                            "func_path_cn": func_path_cn,
                            "func_path_en": func_path_en,
                            "func_des_cn_vector": func_des_cn_vector,
                            "func_des_en": func_des_en,
                            "func_des_en_vector": func_des_en_vector,
                            "func_type": func_type}
            r = requests.post(url, auth=awsauth, json=document, headers=headers)
            
            counts = counts + 1
            if counts % 10000 == 0 :
                print("input: %d" %counts)
            #print("request:" + r.text)
        print("end import")
